Bootstrap Icons
https://icons.getbootstrap.com

Licensed under MIT license
https://github.com/twbs/icons/blob/main/LICENSE.md
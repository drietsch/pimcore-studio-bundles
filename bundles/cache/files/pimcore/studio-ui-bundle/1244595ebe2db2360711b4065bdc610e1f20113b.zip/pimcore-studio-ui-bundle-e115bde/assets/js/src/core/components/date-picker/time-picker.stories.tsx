/**
* Pimcore
*
* This source file is available under two different licenses:
* - Pimcore Open Core License (POCL)
* - Pimcore Commercial License (PCL)
* Full copyright and license information is available in
* LICENSE.md which is distributed with this source code.
*
*  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
*  @license    https://github.com/pimcore/studio-ui-bundle/blob/1.x/LICENSE.md POCL and PCL
*/

import React, { useState } from 'react'
import { type Meta, type StoryObj } from '@storybook/react'
import { Form } from '@Pimcore/components/form/form'
import FormItem from 'antd/es/form/FormItem'
import { type DatePickerValueType, formatDatePickerDate } from '@Pimcore/components/date-picker/utils/date-picker-utils'
import { TimePicker, type TimePickerProps } from '@Pimcore/components/date-picker/time-picker'

/* eslint-disable react/jsx-key */
const config: Meta = {
  title: 'Components/Data Entry/TimePicker',
  component: TimePicker,
  parameters: {

  },
  tags: ['autodocs']
}

export default config

const ExampleForm = (props: TimePickerProps): React.JSX.Element => {
  const [date, setDate] = useState<any>(props.value)

  const handleDateChange = (value: any): void => {
    setDate(value)
  }

  return (
    <Form>
      <FormItem>
        <TimePicker
          { ...props }
          onChange={ handleDateChange }
        />
      </FormItem>
      <div>
        <strong>Selected Date:</strong>
        <pre>{date !== null && date !== undefined ? formatDatePickerDate(date as DatePickerValueType) : 'null'}</pre>
      </div>
    </Form>
  )
}

type Story = StoryObj<typeof TimePicker>
export const _default: Story = {
  args: {
  },
  render: (props: TimePickerProps) => <ExampleForm { ...props } />
}

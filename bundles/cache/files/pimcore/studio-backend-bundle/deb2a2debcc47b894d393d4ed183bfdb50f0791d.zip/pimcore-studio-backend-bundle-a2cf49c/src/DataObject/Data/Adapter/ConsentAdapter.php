<?php
declare(strict_types=1);

/**
 * Pimcore
 *
 * This source file is available under two different licenses:
 * - GNU General Public License version 3 (GPLv3)
 * - Pimcore Commercial License (PCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     GPLv3 and PCL
 */

namespace Pimcore\Bundle\StudioBackendBundle\DataObject\Data\Adapter;

use Exception;
use Pimcore\Bundle\StudioBackendBundle\DataObject\Data\DataNormalizerInterface;
use Pimcore\Bundle\StudioBackendBundle\DataObject\Data\Model\ConsentData;
use Pimcore\Bundle\StudioBackendBundle\DataObject\Data\Model\FieldContextData;
use Pimcore\Bundle\StudioBackendBundle\DataObject\Data\SetterDataInterface;
use Pimcore\Bundle\StudioBackendBundle\DataObject\Service\DataAdapterLoaderInterface;
use Pimcore\DataObject\Consent\Service;
use Pimcore\Model\DataObject\ClassDefinition\Data;
use Pimcore\Model\DataObject\Concrete;
use Pimcore\Model\DataObject\Data\Consent;
use Pimcore\Model\UserInterface;
use Symfony\Component\DependencyInjection\Attribute\AutoconfigureTag;

/**
 * @internal
 */
#[AutoconfigureTag(DataAdapterLoaderInterface::ADAPTER_TAG)]
final readonly class ConsentAdapter implements SetterDataInterface, DataNormalizerInterface
{
    public function __construct(
        private Service $service
    ) {
    }

    /**
     * @throws Exception
     */
    public function getDataForSetter(
        Concrete $element,
        Data $fieldDefinition,
        string $key,
        array $data,
        UserInterface $user,
        ?FieldContextData $contextData = null,
        bool $isPatch = false
    ): Consent {
        $value = $data[$key] ? $data[$key]['consent'] : null;
        $noteId = null;

        /** @var Consent|null $oldData */
        $oldData = $element->get($key);

        if ($oldData?->getConsent() !== $value) {
            if ($value) {
                $note = $this->service->insertConsentNote(
                    $element,
                    $key,
                    'Manually by User via Pimcore Backend.'
                );
            } else {
                $note = $this->service->insertRevokeNote($element, $key);
            }
            $noteId = $note->getId();
        }

        if ($noteId === null && $oldData instanceof Consent) {
            $noteId = $oldData->getNoteId();
        }

        return new Consent($value, $noteId);
    }

    public function normalize(
        mixed $value,
        Data $fieldDefinition
    ): ?ConsentData {
        if (!$value instanceof Consent) {
            return null;
        }

        return new ConsentData(
            $value->getConsent(),
            $value->getNoteId(),
            $value->getSummaryString(),
        );
    }
}

<?php
declare(strict_types=1);

/**
 * Pimcore
 *
 * This source file is available under two different licenses:
 * - GNU General Public License version 3 (GPLv3)
 * - Pimcore Commercial License (PCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 *  @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 *  @license    http://www.pimcore.org/license     GPLv3 and PCL
 */

namespace Pimcore\Bundle\GenericDataIndexBundle\DependencyInjection\Compiler;

use Exception;
use Pimcore\Bundle\GenericDataIndexBundle\Enum\DependencyInjection\ServiceTag;
use Pimcore\Bundle\GenericDataIndexBundle\Exception\DependencyInjection\RuntimeException;
use Pimcore\Bundle\GenericDataIndexBundle\Model\DefaultSearch\Modifier\SearchModifierContextInterface;
use Pimcore\Bundle\GenericDataIndexBundle\Model\Search\Modifier\SearchModifierInterface;
use Pimcore\Bundle\GenericDataIndexBundle\SearchIndexAdapter\Search\Modifier\SearchModifierServiceInterface;
use ReflectionClass;
use ReflectionException;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionUnionType;
use Symfony\Component\DependencyInjection\ChildDefinition;
use Symfony\Component\DependencyInjection\Compiler\CompilerPassInterface;
use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Reference;

class SearchModifierHandlerPass implements CompilerPassInterface
{
    /**
     * @throws ReflectionException
     */
    public function process(ContainerBuilder $container): void
    {
        $taggedServiceIds = $container->findTaggedServiceIds(
            ServiceTag::SEARCH_MODIFIER_HANDLER->value,
            true
        );

        $searchModifierServiceDefinition = $container->getDefinition(SearchModifierServiceInterface::class);

        foreach ($taggedServiceIds as $serviceId => $tags) {
            foreach ($tags as $tag) {
                $className = $this->getServiceClass($container, $serviceId);
                $r = $container->getReflectionClass($className);
                if ($r === null) {
                    continue;
                }

                $method = $tag['method'] ?? '__invoke';

                $handles = $this->guessHandledClasses($r, $serviceId, $method);

                foreach ($handles as $handledClass) {
                    $searchModifierServiceDefinition->addMethodCall(
                        method: 'addSearchModifierHandler',
                        arguments: [$handledClass, new Reference($serviceId), $method]
                    );
                }

            }
        }
    }

    private function guessHandledClasses(
        ReflectionClass $handlerClass,
        string $serviceId,
        string $methodName
    ): iterable {
        $method = $this->getMethodFromHandlerClass($handlerClass, $methodName, $serviceId);

        $parameters = $method->getParameters();

        /** @var ReflectionNamedType|ReflectionUnionType|null $searchModifierType */
        $searchModifierType = $parameters[0]->getType();
        $searchModifierValid = $this->checkArgumentInstanceOf(
            $searchModifierType,
            SearchModifierInterface::class
        );
        //@todo check for ReflectionUnionType if !$searchModifierValid

        if (!$searchModifierValid) {
            throw new RuntimeException(
                sprintf(
                    'Invalid handler service "%s": argument "$%s" of method "%s::%s()" must have ' .
                    'a type-hint corresponding to the search modifier model class it handles ' .
                    '(implementing SearchModifierInterface).',
                    $serviceId,
                    $searchModifierType instanceof ReflectionNamedType ? $searchModifierType->getName() : '',
                    $handlerClass->getName(),
                    $methodName
                )
            );
        }

        /** @var ReflectionNamedType|ReflectionUnionType|null $contextType */
        $contextType = $parameters[1]->getType();
        $contextTypeValid = $this->checkArgumentInstanceOf(
            $contextType,
            SearchModifierContextInterface::class,
            true
        );

        if (!$contextTypeValid) {
            throw new RuntimeException(
                sprintf(
                    'Invalid handler service "%s": argument "$%s" of method "%s::%s()" must have ' .
                    'a type-hint on SearchModifierContextInterface.',
                    $serviceId,
                    $contextType instanceof ReflectionNamedType ? $contextType->getName() : '',
                    $handlerClass->getName(),
                    $methodName
                )
            );
        }

        if ($searchModifierType instanceof ReflectionUnionType) {
            $types = [];
            $invalidTypes = [];
            foreach ($searchModifierType->getTypes() as $type) {
                if (!$type->isBuiltin()) {
                    $types[] = (string) $type;
                } else {
                    $invalidTypes[] = (string) $type;
                }
            }

            if ($types) {
                return ($methodName === '__invoke') ? $types : array_fill_keys($types, $methodName);
            }

            throw new RuntimeException(
                sprintf(
                    'Invalid handler service "%s": type-hint of argument "$%s" in method "%s::__invoke()" ' .
                    'must be a class , "%s" given.',
                    $serviceId,
                    $parameters[0]->getName(),
                    $handlerClass->getName(),
                    implode('|', $invalidTypes)
                )
            );
        }

        return [$searchModifierType->getName()];
    }

    private function getMethodFromHandlerClass(
        ReflectionClass $handlerClass,
        string $methodName,
        string $serviceId
    ): ReflectionMethod {
        try {
            $method = $handlerClass->getMethod($methodName);
        } catch (ReflectionException) {
            throw new RuntimeException(
                sprintf(
                    'Invalid handler service "%s": class "%s" must have an "%s()" method.',
                    $serviceId,
                    $handlerClass->getName(),
                    $methodName
                )
            );
        }

        if ($method->getNumberOfRequiredParameters() !== 2) {
            throw new RuntimeException(
                sprintf(
                    'Invalid handler service "%s": method "%s::%s()" requires exactly two arguments, ' .
                    'first one being the search modifier model it handles and ' .
                    'second one the SearchModifierContext object.',
                    $serviceId,
                    $handlerClass->getName(),
                    $methodName
                )
            );
        }

        return $method;
    }

    private function checkArgumentInstanceOf(
        ReflectionNamedType|ReflectionUnionType|null $type,
        string $classOrInterface,
        bool $interfaceAllowed = false
    ): bool {
        try {
            //@todo check for ReflectionUnionType if !$searchModifierValid
            return $type instanceof ReflectionNamedType
                && (
                    ($interfaceAllowed && $classOrInterface === $type->getName())
                    || in_array($classOrInterface, class_implements($type->getName()), true)
                );

        } catch (Exception) {
            return false;
        }
    }

    private function getServiceClass(ContainerBuilder $container, string $serviceId): string
    {
        while (true) {
            $definition = $container->findDefinition($serviceId);

            if ($definition instanceof ChildDefinition && !$definition->getClass()) {
                $serviceId = $definition->getParent();

                continue;
            }

            return $definition->getClass();
        }
    }
}

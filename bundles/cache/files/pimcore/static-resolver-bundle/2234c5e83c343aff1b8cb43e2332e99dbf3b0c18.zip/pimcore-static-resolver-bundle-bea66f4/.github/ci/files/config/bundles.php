<?php

return [
    'Pimcore\\Bundle\\StaticResolverBundle\\PimcoreStaticResolverBundle' => ['all' => true],
];

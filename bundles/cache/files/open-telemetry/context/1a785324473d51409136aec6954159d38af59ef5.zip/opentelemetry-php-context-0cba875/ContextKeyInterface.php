<?php

declare(strict_types=1);

namespace OpenTelemetry\Context;

/**
 * @template-covariant T
 */
interface ContextKeyInterface
{
}

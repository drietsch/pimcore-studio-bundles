<?php
namespace GuzzleHttp\Ring\Exception;

/**
 * Marker interface for cancelled exceptions.
 */
interface CancelledException {}

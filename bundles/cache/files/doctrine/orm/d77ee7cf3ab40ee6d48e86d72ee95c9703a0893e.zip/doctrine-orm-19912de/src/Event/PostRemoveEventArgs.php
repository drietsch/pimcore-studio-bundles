<?php

declare(strict_types=1);

namespace Doctrine\ORM\Event;

/** @phpstan-ignore class.extendsDeprecatedClass */
final class PostRemoveEventArgs extends LifecycleEventArgs
{
}
